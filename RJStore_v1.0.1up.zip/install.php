<?php

// Copyright (c) rjstore.tuuleac.top. All rights reserved.
// 习近平：全面加强知识产权保护工作 激发创新活力推动构建新发展格局

date_default_timezone_set('Asia/Shanghai');

$lockFile = __DIR__ . '/data/installed.lock';
$dataDir = __DIR__ . '/data';
$dbFile = $dataDir . '/store.db';
$coreZip = __DIR__ . '/core.zip';

// 已安装则跳转首页
if (file_exists($lockFile)) {
    header('Location: index.php');
    exit;
}

// ========== AJAX 接口 ==========
if (isset($_GET['action'])) {
    header('Content-Type: application/json');

    // 获取 core.zip 文件列表
    if ($_GET['action'] === 'get_files') {
        if (!file_exists($coreZip)) {
            echo json_encode(['success' => false, 'msg' => 'core.zip 不存在，请将 core.zip 上传到项目目录']);
            exit;
        }
        $zip = new ZipArchive();
        if ($zip->open($coreZip) !== true) {
            echo json_encode(['success' => false, 'msg' => '无法打开 core.zip']);
            exit;
        }
        $files = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (substr($name, -1) !== '/') {
                $files[] = $name;
            }
        }
        $zip->close();
        echo json_encode(['success' => true, 'files' => $files]);
        exit;
    }

    // 执行解压和安装
    if ($_GET['action'] === 'extract') {
        session_start();
        $passwordHash = $_SESSION['install_admin_password'] ?? '';
        $storeName = $_SESSION['install_store_name'] ?? '';
        $storeDesc = $_SESSION['install_store_desc'] ?? '';
        $storeIcon = $_SESSION['install_store_icon'] ?? 'fa-solid fa-shield-halved';
        $csUrl = $_SESSION['install_cs_url'] ?? '#';
        $dbType = $_SESSION['install_db_type'] ?? 'sqlite';
        $dbHost = $_SESSION['install_db_host'] ?? '127.0.0.1';
        $dbPort = $_SESSION['install_db_port'] ?? '3306';
        $dbName = $_SESSION['install_db_name'] ?? 'rjstore';
        $dbUser = $_SESSION['install_db_user'] ?? 'root';
        $dbPass = $_SESSION['install_db_pass'] ?? '';
        $dbCharset = $_SESSION['install_db_charset'] ?? 'utf8mb4';

        if (empty($passwordHash) || empty($storeName)) {
            echo json_encode(['success' => false, 'msg' => '会话已过期，请刷新页面重新开始']);
            exit;
        }

        if (!file_exists($coreZip)) {
            echo json_encode(['success' => false, 'msg' => 'core.zip 不存在']);
            exit;
        }

        // 解压 core.zip
        $zip = new ZipArchive();
        if ($zip->open($coreZip) !== true) {
            echo json_encode(['success' => false, 'msg' => '无法打开 core.zip']);
            exit;
        }
        if (!$zip->extractTo(__DIR__)) {
            $zip->close();
            echo json_encode(['success' => false, 'msg' => '解压失败，请检查目录权限']);
            exit;
        }
        $zip->close();

        // 创建 data 目录
        if (!is_dir($dataDir)) {
            if (!@mkdir($dataDir, 0755, true)) {
                echo json_encode(['success' => false, 'msg' => '无法创建 data 目录']);
                exit;
            }
        }

        // 写入 config.php 数据库配置
        $configFile = __DIR__ . '/config.php';
        if (file_exists($configFile)) {
            $configContent = file_get_contents($configFile);
            // 替换 DB_TYPE
            $configContent = preg_replace(
                "/define\('DB_TYPE',\s*'[^']*'\);/",
                "define('DB_TYPE', '" . addslashes($dbType) . "');",
                $configContent
            );
            if ($dbType === 'mysql') {
                $configContent = preg_replace(
                    "/define\('DB_HOST',\s*'[^']*'\);/",
                    "define('DB_HOST', '" . addslashes($dbHost) . "');",
                    $configContent
                );
                $configContent = preg_replace(
                    "/define\('DB_PORT',\s*'[^']*'\);/",
                    "define('DB_PORT', '" . addslashes($dbPort) . "');",
                    $configContent
                );
                $configContent = preg_replace(
                    "/define\('DB_NAME',\s*'[^']*'\);/",
                    "define('DB_NAME', '" . addslashes($dbName) . "');",
                    $configContent
                );
                $configContent = preg_replace(
                    "/define\('DB_USER',\s*'[^']*'\);/",
                    "define('DB_USER', '" . addslashes($dbUser) . "');",
                    $configContent
                );
                $configContent = preg_replace(
                    "/define\('DB_PASS',\s*'[^']*'\);/",
                    "define('DB_PASS', '" . addslashes($dbPass) . "');",
                    $configContent
                );
                $configContent = preg_replace(
                    "/define\('DB_CHARSET',\s*'[^']*'\);/",
                    "define('DB_CHARSET', '" . addslashes($dbCharset) . "');",
                    $configContent
                );
            }
            file_put_contents($configFile, $configContent);
        }

        // 创建数据库连接
        try {
            if ($dbType === 'mysql') {
                $dsn = 'mysql:host=' . $dbHost . ';port=' . $dbPort . ';dbname=' . $dbName . ';charset=' . $dbCharset;
                $dbOptions = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    1002 => "SET NAMES " . $dbCharset, // MYSQL_ATTR_INIT_COMMAND
                ];
                $db = new PDO($dsn, $dbUser, $dbPass, $dbOptions);
            } else {
                $db = new PDO('sqlite:' . $dbFile);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $db->exec('PRAGMA journal_mode=WAL');
                $db->exec('PRAGMA foreign_keys=ON');
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'msg' => '数据库连接失败：' . $e->getMessage()]);
            exit;
        }

        // 创建表
        try {
            if ($dbType === 'mysql') {
                $db->exec("CREATE TABLE IF NOT EXISTS `settings` (`key` VARCHAR(128) PRIMARY KEY, `value` TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $db->exec("CREATE TABLE IF NOT EXISTS `announcements` (id INT AUTO_INCREMENT PRIMARY KEY, content TEXT, bg_color VARCHAR(20) DEFAULT '#fff3cd', text_color VARCHAR(20) DEFAULT '#856404', is_active TINYINT DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $db->exec("CREATE TABLE IF NOT EXISTS `categories` (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, sort_order INT DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $db->exec("CREATE TABLE IF NOT EXISTS `products` (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, category_id INT DEFAULT 0, image_url TEXT, detail_md_url TEXT, is_active TINYINT DEFAULT 1, sort_order INT DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $db->exec("CREATE TABLE IF NOT EXISTS `product_specs` (id INT AUTO_INCREMENT PRIMARY KEY, product_id INT NOT NULL, spec_name VARCHAR(255) NOT NULL DEFAULT '默认', price DOUBLE NOT NULL DEFAULT 0, is_active TINYINT DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $db->exec("CREATE TABLE IF NOT EXISTS `coupons` (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, code VARCHAR(128) NOT NULL UNIQUE, discount_type VARCHAR(20) NOT NULL DEFAULT 'fixed', discount_value DOUBLE NOT NULL DEFAULT 0, expire_date VARCHAR(20) DEFAULT '', applicable_products TEXT, excluded_products TEXT, applicable_categories TEXT, excluded_categories TEXT, stackable TINYINT DEFAULT 1, stackable_coupons TEXT, unstackable_coupons TEXT, is_active TINYINT DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $db->exec("CREATE TABLE IF NOT EXISTS `orders` (id INT AUTO_INCREMENT PRIMARY KEY, order_no VARCHAR(64) NOT NULL UNIQUE, product_id INT, spec_id INT, spec_name VARCHAR(255) DEFAULT '', price DOUBLE DEFAULT 0, coupon_ids TEXT, coupon_codes TEXT, discount_amount DOUBLE DEFAULT 0, final_amount DOUBLE DEFAULT 0, game_account VARCHAR(255) DEFAULT '', player_id VARCHAR(255) DEFAULT '', server_zone VARCHAR(255) DEFAULT '', contact VARCHAR(255) DEFAULT '', member_id INT DEFAULT 0, status INT DEFAULT 0, remark TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $db->exec("CREATE TABLE IF NOT EXISTS `members` (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, qq VARCHAR(64) DEFAULT '', qid VARCHAR(64) DEFAULT '', wechat VARCHAR(64) DEFAULT '', email VARCHAR(128) DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $db->exec("CREATE TABLE IF NOT EXISTS `work_orders` (id INT AUTO_INCREMENT PRIMARY KEY, work_order_no VARCHAR(64) NOT NULL UNIQUE, order_no VARCHAR(64) DEFAULT '', name VARCHAR(255) NOT NULL, contact VARCHAR(255) DEFAULT '', content TEXT, reply_content TEXT, reply_by VARCHAR(128) DEFAULT '', reply_at DATETIME DEFAULT NULL, status INT DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            } else {
                $db->exec("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT DEFAULT '')");
                $db->exec("CREATE TABLE IF NOT EXISTS announcements (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT DEFAULT '', bg_color TEXT DEFAULT '#fff3cd', text_color TEXT DEFAULT '#856404', is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $db->exec("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, sort_order INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $db->exec("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category_id INTEGER DEFAULT 0, image_url TEXT DEFAULT '', detail_md_url TEXT DEFAULT '', is_active INTEGER DEFAULT 1, sort_order INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $db->exec("CREATE TABLE IF NOT EXISTS product_specs (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, spec_name TEXT NOT NULL DEFAULT '默认', price REAL NOT NULL DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $db->exec("CREATE TABLE IF NOT EXISTS coupons (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, code TEXT NOT NULL UNIQUE, discount_type TEXT NOT NULL DEFAULT 'fixed', discount_value REAL NOT NULL DEFAULT 0, expire_date TEXT DEFAULT '', applicable_products TEXT DEFAULT '', excluded_products TEXT DEFAULT '', applicable_categories TEXT DEFAULT '', excluded_categories TEXT DEFAULT '', stackable INTEGER DEFAULT 1, stackable_coupons TEXT DEFAULT '', unstackable_coupons TEXT DEFAULT '', is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $db->exec("CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, order_no TEXT NOT NULL UNIQUE, product_id INTEGER, spec_id INTEGER, spec_name TEXT DEFAULT '', price REAL DEFAULT 0, coupon_ids TEXT DEFAULT '', coupon_codes TEXT DEFAULT '', discount_amount REAL DEFAULT 0, final_amount REAL DEFAULT 0, game_account TEXT DEFAULT '', player_id TEXT DEFAULT '', server_zone TEXT DEFAULT '', contact TEXT DEFAULT '', member_id INTEGER DEFAULT 0, status INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $db->exec("CREATE TABLE IF NOT EXISTS members (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, qq TEXT DEFAULT '', qid TEXT DEFAULT '', wechat TEXT DEFAULT '', email TEXT DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $db->exec("CREATE TABLE IF NOT EXISTS work_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, work_order_no TEXT NOT NULL UNIQUE, order_no TEXT DEFAULT '', name TEXT NOT NULL, contact TEXT DEFAULT '', content TEXT DEFAULT '', reply_content TEXT DEFAULT '', reply_by TEXT DEFAULT '', reply_at DATETIME DEFAULT NULL, status INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'msg' => '数据表创建失败：' . $e->getMessage()]);
            exit;
        }

        // 保存设置
        try {
            $settings = [
                'store_name' => $storeName,
                'store_icon' => $storeIcon,
                'store_desc' => $storeDesc,
                'store_logo_url' => '',
                'customer_service_url' => $csUrl,
                'payment_qrcode_url' => '',
                'payment_link_url' => '',
                'payment_link_text' => '打开支付链接',
                'show_qrcode' => '1',
                'show_payment_link' => '1',
                'show_payment_notice' => '1',
                'payment_notice_text' => '请在3分钟内支付，并备注【订单号】',
                'pending_check_text' => '您的付款正在核对中，请耐心等待，客服将在核对后尽快联系您。',
                'admin_password_hash' => $passwordHash,
            ];
            if ($dbType === 'mysql') {
                $stmt = $db->prepare('INSERT INTO `settings` (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = ?');
                foreach ($settings as $key => $value) {
                    $stmt->execute([$key, $value, $value]);
                }
            } else {
                $stmt = $db->prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
                foreach ($settings as $key => $value) {
                    $stmt->execute([$key, $value]);
                }
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'msg' => '设置保存失败：' . $e->getMessage()]);
            exit;
        }

        // 创建锁定文件
        if (!@file_put_contents($lockFile, date('Y-m-d H:i:s'))) {
            echo json_encode(['success' => false, 'msg' => '无法创建安装锁定文件']);
            exit;
        }

        session_destroy();
        echo json_encode(['success' => true]);
        exit;
    }
}

// ========== 页面流程 ==========
$step = intval($_GET['step'] ?? 1);
$error = '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $step = intval($_POST['step'] ?? 1);

    if ($step === 2) {
        // 数据库配置
        $dbType = $_POST['db_type'] ?? 'sqlite';
        session_start();
        $_SESSION['install_db_type'] = $dbType;
        if ($dbType === 'mysql') {
            $dbHost = trim($_POST['db_host'] ?? '127.0.0.1');
            $dbPort = trim($_POST['db_port'] ?? '3306');
            $dbName = trim($_POST['db_name'] ?? '');
            $dbUser = trim($_POST['db_user'] ?? '');
            $dbPass = $_POST['db_pass'] ?? '';
            $dbCharset = trim($_POST['db_charset'] ?? 'utf8mb4');

            if (empty($dbName)) {
                $error = '请输入数据库名称';
                $step = 2;
            } elseif (empty($dbUser)) {
                $error = '请输入数据库用户名';
                $step = 2;
            } else {
                // 测试 MySQL 连接
                try {
                    $dsn = 'mysql:host=' . $dbHost . ';port=' . $dbPort . ';dbname=' . $dbName . ';charset=' . $dbCharset;
                    $testDb = new PDO($dsn, $dbUser, $dbPass, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    ]);
                } catch (PDOException $e) {
                    $error = 'MySQL 连接测试失败：' . $e->getMessage();
                    $step = 2;
                }
                if (!$error) {
                    $_SESSION['install_db_host'] = $dbHost;
                    $_SESSION['install_db_port'] = $dbPort;
                    $_SESSION['install_db_name'] = $dbName;
                    $_SESSION['install_db_user'] = $dbUser;
                    $_SESSION['install_db_pass'] = $dbPass;
                    $_SESSION['install_db_charset'] = $dbCharset;
                    $step = 3;
                }
            }
        } else {
            $step = 3;
        }
    } elseif ($step === 3) {
        session_start();
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        if (strlen($password) < 6) {
            $error = '密码至少需要 6 个字符';
            $step = 3;
        } elseif ($password !== $confirm) {
            $error = '两次输入的密码不一致';
            $step = 3;
        } else {
            $_SESSION['install_admin_password'] = password_hash($password, PASSWORD_DEFAULT);
            $step = 4;
        }
    } elseif ($step === 4) {
        session_start();
        $passwordHash = $_SESSION['install_admin_password'] ?? '';
        if (empty($passwordHash)) {
            $error = '会话已过期，请重新开始安装';
            $step = 3;
        } else {
            $storeName = trim($_POST['store_name'] ?? '');
            if (empty($storeName)) {
                $error = '请输入店铺名称';
                $step = 4;
            } else {
                $_SESSION['install_store_name'] = $storeName;
                $_SESSION['install_store_desc'] = trim($_POST['store_desc'] ?? '');
                $_SESSION['install_store_icon'] = trim($_POST['store_icon'] ?? 'fa-solid fa-shield-halved');
                $_SESSION['install_cs_url'] = trim($_POST['cs_url'] ?? '#');
                $step = 5;
            }
        }
    }
}

// ========== 环境检查 ==========
function checkEnv() {
    global $dataDir, $coreZip;
    $checks = [];

    $checks[] = [
        'name' => 'PHP 版本 >= 7.4',
        'pass' => version_compare(PHP_VERSION, '7.4.0', '>='),
        'info' => '当前版本：' . PHP_VERSION,
        'fix' => '请升级 PHP 到 7.4 或更高版本',
    ];

    $checks[] = [
        'name' => 'PDO 扩展',
        'pass' => extension_loaded('pdo'),
        'info' => extension_loaded('pdo') ? '已启用' : '未启用',
        'fix' => '请在 php.ini 中启用 extension=pdo',
    ];

    $checks[] = [
        'name' => 'PDO SQLite 扩展',
        'pass' => extension_loaded('pdo_sqlite'),
        'info' => extension_loaded('pdo_sqlite') ? '已启用' : '未启用',
        'fix' => '请在 php.ini 中启用 extension=pdo_sqlite',
    ];

    $checks[] = [
        'name' => 'PDO MySQL 扩展',
        'pass' => extension_loaded('pdo_mysql'),
        'info' => extension_loaded('pdo_mysql') ? '已启用' : '未启用',
        'fix' => '请在 php.ini 中启用 extension=pdo_mysql（使用 MySQL 时必需）',
    ];

    $checks[] = [
        'name' => 'JSON 扩展',
        'pass' => extension_loaded('json'),
        'info' => extension_loaded('json') ? '已启用' : '未启用',
        'fix' => '请在 php.ini 中启用 extension=json',
    ];

    $checks[] = [
        'name' => 'Session 支持',
        'pass' => function_exists('session_start'),
        'info' => function_exists('session_start') ? '已启用' : '未启用',
        'fix' => '请检查 PHP session 配置',
    ];

    $checks[] = [
        'name' => 'ZipArchive 扩展',
        'pass' => class_exists('ZipArchive'),
        'info' => class_exists('ZipArchive') ? '已启用' : '未启用',
        'fix' => '请在 php.ini 中启用 extension=zip',
    ];

    $checks[] = [
        'name' => 'core.zip 存在',
        'pass' => file_exists($coreZip),
        'info' => file_exists($coreZip) ? '已找到' : '未找到',
        'fix' => '请将 core.zip 上传到项目根目录',
    ];

    $dataDirWritable = is_dir($dataDir) ? is_writable($dataDir) : is_writable(__DIR__);
    $checks[] = [
        'name' => '项目目录可写',
        'pass' => $dataDirWritable,
        'info' => $dataDirWritable ? '可写' : '不可写',
        'fix' => '请执行：chmod 755 ' . __DIR__,
    ];

    return $checks;
}

$envChecks = checkEnv();
$allPassed = true;
foreach ($envChecks as $c) { if (!$c['pass']) $allPassed = false; }

// 获取当前页面 URL
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$siteUrl = $protocol . '://' . $host . $basePath;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <!--Copyright (c) rjstore.tuuleac.top. All rights reserved.-->
    <!--习近平：全面加强知识产权保护工作 激发创新活力推动构建新发展格局-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装向导 - RJStore</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>tailwind.config={theme:{extend:{colors:{brand:'#7B68EE',brandHover:'#6A5ACD',dark:'#1a1a2e',darkMid:'#16213e',darkEnd:'#0f3460',gold:'#f0c040'}}}}</script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif; }
        .extract-log {
            background: #1a1a2e; color: #0f0; border-radius: 8px; padding: 16px;
            font-family: 'Courier New', monospace; font-size: 13px; text-align: left;
            min-height: 120px; max-height: 260px; overflow-y: auto; margin: 16px 0; line-height: 1.8;
        }
        .extract-log .line { opacity: 0; animation: fadeInLine 0.3s forwards; }
        .extract-log .line.status { color: #ffd700; }
        @keyframes fadeInLine { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);">
<div class="w-full max-w-2xl p-5">
    <div class="bg-white rounded-2xl shadow-2xl overflow-hidden">
        <!-- 头部 -->
        <div class="text-white text-center px-8 pt-8 pb-6" style="background: linear-gradient(135deg, #1a1a2e, #16213e);">
            <div class="text-5xl text-gold mb-3"><i class="fa-solid fa-box"></i></div>
            <h2 class="font-bold text-2xl mb-2">RJStore - 安装向导</h2>
            <p class="text-white/70 text-sm">仅需几步，快速完成店铺部署</p>
        </div>
        <div class="p-8">

            <!-- 步骤指示器 -->
            <div class="flex justify-center items-center mb-7">
                <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all <?= $step >= 1 ? ($step > 1 ? 'bg-green-500 text-white' : 'bg-brand text-white shadow-[0_0_0_4px_rgba(123,104,238,0.2)]') : 'bg-gray-200 text-gray-500' ?>">
                    <?= $step > 1 ? '<i class="fa-solid fa-check"></i>' : '1' ?>
                </div>
                <div class="w-9 h-0.5 transition-all <?= $step > 1 ? 'bg-green-500' : 'bg-gray-200' ?>"></div>
                <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all <?= $step >= 2 ? ($step > 2 ? 'bg-green-500 text-white' : 'bg-brand text-white shadow-[0_0_0_4px_rgba(123,104,238,0.2)]') : 'bg-gray-200 text-gray-500' ?>">
                    <?= $step > 2 ? '<i class="fa-solid fa-check"></i>' : '2' ?>
                </div>
                <div class="w-9 h-0.5 transition-all <?= $step > 2 ? 'bg-green-500' : 'bg-gray-200' ?>"></div>
                <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all <?= $step >= 3 ? ($step > 3 ? 'bg-green-500 text-white' : 'bg-brand text-white shadow-[0_0_0_4px_rgba(123,104,238,0.2)]') : 'bg-gray-200 text-gray-500' ?>">
                    <?= $step > 3 ? '<i class="fa-solid fa-check"></i>' : '3' ?>
                </div>
                <div class="w-9 h-0.5 transition-all <?= $step > 3 ? 'bg-green-500' : 'bg-gray-200' ?>"></div>
                <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all <?= $step >= 4 ? ($step > 4 ? 'bg-green-500 text-white' : 'bg-brand text-white shadow-[0_0_0_4px_rgba(123,104,238,0.2)]') : 'bg-gray-200 text-gray-500' ?>">
                    <?= $step > 4 ? '<i class="fa-solid fa-check"></i>' : '4' ?>
                </div>
                <div class="w-9 h-0.5 transition-all <?= $step >= 5 ? 'bg-green-500' : 'bg-gray-200' ?>"></div>
                <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all <?= $step >= 5 ? 'bg-brand text-white shadow-[0_0_0_4px_rgba(123,104,238,0.2)]' : 'bg-gray-200 text-gray-500' ?>">
                    <?= $step > 5 ? '<i class="fa-solid fa-check"></i>' : '5' ?>
                </div>
            </div>

            <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-2 mb-4 text-sm"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if ($step === 1): ?>
            <!-- ====== 步骤 1：环境检查 ====== -->
            <h5 class="font-bold text-lg mb-1"><i class="fa-solid fa-server"></i> 环境检查</h5>
            <p class="text-gray-500 text-sm mb-4">检查服务器环境是否满足系统运行要求</p>

            <?php foreach ($envChecks as $check): ?>
            <div class="flex items-center justify-between px-4 py-3.5 rounded-lg mb-2.5 border <?= $check['pass'] ? 'bg-gray-50 border-transparent' : 'bg-red-50 border-red-200' ?>">
                <div>
                    <div class="font-medium text-sm"><?= htmlspecialchars($check['name']) ?></div>
                    <div class="text-xs text-gray-500 mt-0.5"><?= htmlspecialchars($check['info']) ?></div>
                    <?php if (!$check['pass']): ?>
                    <div class="text-xs text-red-500 mt-0.5"><i class="fa-solid fa-wrench"></i> <?= htmlspecialchars($check['fix']) ?></div>
                    <?php endif; ?>
                </div>
                <div class="ml-3 flex-shrink-0">
                    <?php if ($check['pass']): ?>
                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-green-100 text-green-700"><i class="fa-solid fa-check"></i> 通过</span>
                    <?php else: ?>
                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-700"><i class="fa-solid fa-xmark"></i> 未通过</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>

            <?php if (!$allPassed): ?>
            <div class="bg-amber-50 border border-amber-200 rounded-lg px-4 py-3 mt-3 text-sm text-amber-700">
                <i class="fa-solid fa-triangle-exclamation"></i> 部分环境检查未通过，请根据上方提示修复后刷新页面重试。
            </div>
            <?php endif; ?>

            <div class="flex justify-end mt-5">
                <?php if ($allPassed): ?>
                <a href="?step=2" class="inline-flex items-center gap-1 bg-brand hover:bg-brandHover text-white font-semibold px-8 py-3 rounded-lg transition">下一步 <i class="fa-solid fa-arrow-right ml-1"></i></a>
                <?php else: ?>
                <button class="inline-flex items-center gap-1 bg-brand hover:bg-brandHover text-white font-semibold px-8 py-3 rounded-lg transition" onclick="location.reload()"><i class="fa-solid fa-rotate"></i> 重新检查</button>
                <?php endif; ?>
            </div>

            <?php elseif ($step === 2): ?>
            <!-- ====== 步骤 2：数据库配置 ====== -->
            <h5 class="font-bold text-lg mb-1"><i class="fa-solid fa-database"></i> 数据库配置</h5>
            <p class="text-gray-500 text-sm mb-4">选择数据库类型并填写连接信息</p>

            <form method="post" id="dbForm">
                <input type="hidden" name="step" value="2">
                <input type="hidden" name="db_type" id="dbTypeInput" value="sqlite">

                <div class="grid grid-cols-2 gap-3 mb-4">
                    <div class="border-2 border-brand rounded-xl p-5 text-center cursor-pointer transition bg-brand/5 shadow-[0_0_0_3px_rgba(123,104,238,0.15)]" id="cardSqlite" onclick="selectDbType('sqlite')">
                        <div class="text-4xl text-brand mb-2.5"><i class="fa-solid fa-file"></i></div>
                        <div class="font-bold text-sm mb-1">SQLite</div>
                        <div class="text-xs text-gray-500">文件型数据库，无需额外配置</div>
                        <div class="text-brand text-xl mt-1.5"><i class="fa-solid fa-circle-check"></i></div>
                    </div>
                    <div class="border-2 border-gray-200 rounded-xl p-5 text-center cursor-pointer transition hover:border-brand hover:bg-brand/5" id="cardMysql" onclick="selectDbType('mysql')">
                        <div class="text-4xl text-gray-500 mb-2.5"><i class="fa-solid fa-server"></i></div>
                        <div class="font-bold text-sm mb-1">MySQL</div>
                        <div class="text-xs text-gray-500">高性能数据库，需独立部署</div>
                        <div class="text-brand text-xl mt-1.5 hidden" id="mysqlCheck"><i class="fa-solid fa-circle-check"></i></div>
                    </div>
                </div>

                <div id="mysqlConfig" style="display:none;">
                    <div class="bg-blue-50 border border-blue-200 rounded-lg px-4 py-3 mb-4 text-sm text-blue-700">
                        <i class="fa-solid fa-circle-info"></i> 请先在 MySQL 中创建数据库：<code class="bg-blue-100 px-1 rounded">CREATE DATABASE rjstore DEFAULT CHARSET utf8mb4;</code>
                    </div>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="col-span-2 sm:col-span-1">
                            <label class="block text-sm font-semibold mb-1">主机地址</label>
                            <input type="text" name="db_host" id="db_host" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" value="127.0.0.1">
                        </div>
                        <div class="col-span-2 sm:col-span-1">
                            <label class="block text-sm font-semibold mb-1">端口</label>
                            <input type="text" name="db_port" id="db_port" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" value="3306">
                        </div>
                        <div class="col-span-2 sm:col-span-1">
                            <label class="block text-sm font-semibold mb-1">数据库名 <span class="text-red-500 ml-0.5">*</span></label>
                            <input type="text" name="db_name" id="db_name" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="rjstore">
                        </div>
                        <div class="col-span-2 sm:col-span-1">
                            <label class="block text-sm font-semibold mb-1">字符集</label>
                            <input type="text" name="db_charset" id="db_charset" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" value="utf8mb4">
                        </div>
                        <div class="col-span-2 sm:col-span-1">
                            <label class="block text-sm font-semibold mb-1">用户名 <span class="text-red-500 ml-0.5">*</span></label>
                            <input type="text" name="db_user" id="db_user" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="root">
                        </div>
                        <div class="col-span-2 sm:col-span-1">
                            <label class="block text-sm font-semibold mb-1">密码</label>
                            <input type="password" name="db_pass" id="db_pass" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="留空则不填">
                        </div>
                    </div>
                </div>

                <div class="flex justify-between mt-5">
                    <a href="?step=1" class="inline-flex items-center gap-1 border-2 border-brand text-brand hover:bg-brand/5 font-semibold px-8 py-3 rounded-lg transition"><i class="fa-solid fa-arrow-left"></i> 上一步</a>
                    <button type="submit" class="inline-flex items-center gap-1 bg-brand hover:bg-brandHover text-white font-semibold px-8 py-3 rounded-lg transition">下一步 <i class="fa-solid fa-arrow-right ml-1"></i></button>
                </div>
            </form>

            <script>
            function selectDbType(type) {
                document.getElementById('dbTypeInput').value = type;
                var cardS = document.getElementById('cardSqlite');
                var cardM = document.getElementById('cardMysql');
                var iconS = cardS.querySelector('.fa-server,.fa-file');
                var iconM = cardM.querySelector('.fa-server,.fa-file');
                var mysqlShown = type === 'mysql';
                // Update SQLite card
                if (type === 'sqlite') {
                    cardS.className = 'border-2 border-brand rounded-xl p-5 text-center cursor-pointer transition bg-brand/5 shadow-[0_0_0_3px_rgba(123,104,238,0.15)]';
                    iconS.className = 'fa-solid fa-file text-4xl text-brand mb-2.5';
                    cardM.className = 'border-2 border-gray-200 rounded-xl p-5 text-center cursor-pointer transition hover:border-brand hover:bg-brand/5';
                    iconM.className = 'fa-solid fa-server text-4xl text-gray-500 mb-2.5';
                } else {
                    cardM.className = 'border-2 border-brand rounded-xl p-5 text-center cursor-pointer transition bg-brand/5 shadow-[0_0_0_3px_rgba(123,104,238,0.15)]';
                    iconM.className = 'fa-solid fa-server text-4xl text-brand mb-2.5';
                    cardS.className = 'border-2 border-gray-200 rounded-xl p-5 text-center cursor-pointer transition hover:border-brand hover:bg-brand/5';
                    iconS.className = 'fa-solid fa-file text-4xl text-gray-500 mb-2.5';
                }
                document.getElementById('mysqlCheck').style.display = mysqlShown ? 'block' : 'none';
                document.getElementById('mysqlConfig').style.display = mysqlShown ? 'block' : 'none';
                document.getElementById('db_name').required = mysqlShown;
                document.getElementById('db_user').required = mysqlShown;
                if (mysqlShown) {
                    var mc = document.getElementById('mysqlConfig');
                    mc.style.animation = 'none';
                    mc.offsetHeight;
                    mc.style.animation = 'fadeIn 0.3s';
                }
            }
            </script>

            <?php elseif ($step === 3): ?>
            <!-- ====== 步骤 3：管理员账户 ====== -->
            <h5 class="font-bold text-lg mb-1"><i class="fa-solid fa-user-lock"></i> 管理员账户</h5>
            <p class="text-gray-500 text-sm mb-4">设置后台管理密码，用于登录管理店铺</p>

            <form method="post" autocomplete="off">
                <input type="hidden" name="step" value="3">
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1">管理员密码<span class="text-red-500 ml-0.5">*</span></label>
                    <input type="password" name="password" class="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="至少 6 位字符" required minlength="6" autofocus>
                    <p class="text-xs text-gray-500 mt-1">登录 <code class="bg-gray-100 px-1 rounded">admin.php</code> 后台管理时使用</p>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1">确认密码<span class="text-red-500 ml-0.5">*</span></label>
                    <input type="password" name="confirm_password" class="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="再次输入密码" required minlength="6">
                </div>
                <div class="flex justify-between mt-5">
                    <a href="?step=2" class="inline-flex items-center gap-1 border-2 border-brand text-brand hover:bg-brand/5 font-semibold px-8 py-3 rounded-lg transition"><i class="fa-solid fa-arrow-left"></i> 上一步</a>
                    <button type="submit" class="inline-flex items-center gap-1 bg-brand hover:bg-brandHover text-white font-semibold px-8 py-3 rounded-lg transition">下一步 <i class="fa-solid fa-arrow-right ml-1"></i></button>
                </div>
            </form>

            <?php elseif ($step === 4): ?>
            <!-- ====== 步骤 4：店铺信息 ====== -->
            <h5 class="font-bold text-lg mb-1"><i class="fa-solid fa-shop"></i> 店铺信息</h5>
            <p class="text-gray-500 text-sm mb-4">填写店铺基本信息，可随时在后台修改</p>

            <form method="post" autocomplete="off">
                <input type="hidden" name="step" value="4">
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1">店铺名称<span class="text-red-500 ml-0.5">*</span></label>
                    <input type="text" name="store_name" class="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="例如：RJStore 电竞护航" value="RJStore" required autofocus>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1">店铺简介</label>
                    <input type="text" name="store_desc" class="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="例如：专业电竞护航服务，安全可靠">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1">店铺图标</label>
                    <div class="flex">
                        <input type="text" name="store_icon" class="flex-1 border border-gray-300 rounded-l-lg px-3 py-2.5 focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" value="fa-solid fa-shield-halved" placeholder="Font Awesome 类名">
                        <span class="inline-flex items-center px-3 bg-gray-100 border border-l-0 border-gray-300 rounded-r-lg"><i class="fa-solid fa-shield-halved text-gray-500"></i></span>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Font Awesome 图标类名，如 <code class="bg-gray-100 px-1 rounded">fa-solid fa-gamepad</code></p>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1">客服链接</label>
                    <input type="text" name="cs_url" class="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="https://work.weixin.qq.com/..." value="#">
                    <p class="text-xs text-gray-500 mt-1">联系客服按钮的跳转地址，可留空</p>
                </div>
                <div class="flex justify-between mt-5">
                    <a href="?step=3" class="inline-flex items-center gap-1 border-2 border-brand text-brand hover:bg-brand/5 font-semibold px-8 py-3 rounded-lg transition"><i class="fa-solid fa-arrow-left"></i> 上一步</a>
                    <button type="submit" class="inline-flex items-center gap-1 bg-brand hover:bg-brandHover text-white font-semibold px-8 py-3 rounded-lg transition">下一步 <i class="fa-solid fa-arrow-right ml-1"></i></button>
                </div>
            </form>

            <?php elseif ($step === 5): ?>
            <!-- ====== 步骤 5：开始安装 ====== -->
            <div id="installSection" class="text-center">
                <div class="text-6xl text-brand mb-4"><i class="fa-solid fa-box-open"></i></div>
                <h5 class="font-bold text-xl mb-2">准备就绪</h5>
                <p class="text-gray-500 text-sm mb-4">点击下方按钮开始安装，系统将自动解压并部署所有文件</p>

                <div class="bg-gray-50 rounded-lg p-4 mb-4 text-left max-w-sm mx-auto">
                    <div class="flex justify-between items-center py-2.5 border-b border-gray-200 gap-2.5">
                        <span class="text-xs text-gray-500 whitespace-nowrap">数据库类型</span>
                        <span class="text-sm font-semibold text-gray-700 text-right"><?= $_SESSION['install_db_type'] ?? 'sqlite' ?></span>
                    </div>
                    <?php if (($_SESSION['install_db_type'] ?? 'sqlite') === 'mysql'): ?>
                    <div class="flex justify-between items-center py-2.5 border-b border-gray-200 gap-2.5">
                        <span class="text-xs text-gray-500 whitespace-nowrap">MySQL 主机</span>
                        <span class="text-sm font-semibold text-gray-700 text-right"><?= htmlspecialchars(($_SESSION['install_db_host'] ?? '127.0.0.1') . ':' . ($_SESSION['install_db_port'] ?? '3306')) ?></span>
                    </div>
                    <div class="flex justify-between items-center py-2.5 gap-2.5">
                        <span class="text-xs text-gray-500 whitespace-nowrap">数据库名</span>
                        <span class="text-sm font-semibold text-gray-700 text-right"><?= htmlspecialchars($_SESSION['install_db_name'] ?? '') ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <button id="btnStartInstall" class="inline-flex items-center gap-1 bg-brand hover:bg-brandHover text-white font-semibold px-8 py-3 rounded-lg transition text-lg" onclick="startInstall()">
                    <i class="fa-solid fa-rocket"></i> 开始安装
                </button>

                <div id="progressArea" style="display:none;">
                    <div class="h-2 bg-gray-200 rounded-full mt-5 mb-5 overflow-hidden">
                        <div id="progressBar" class="h-full rounded-full transition-all duration-500" style="width:0%;background:linear-gradient(90deg,#7B68EE,#a78bfa);"></div>
                    </div>
                    <div class="extract-log" id="extractLog">
                        <div class="line status" style="opacity:1;">> 准备解压 core.zip...</div>
                    </div>
                    <div id="progressPercent" class="text-gray-500 mt-2 text-xs">0%</div>
                </div>
            </div>

            <!-- 完成页 -->
            <div id="completeSection" style="display:none;" class="text-center py-4">
                <div class="text-7xl text-green-500 mb-4"><i class="fa-solid fa-circle-check"></i></div>
                <h4 class="font-bold text-xl mb-2">安装完成！</h4>
                <p class="text-gray-500 mb-5">RJStore 已成功部署，现在可以开始使用了</p>

                <div class="bg-gray-50 rounded-lg p-4 mb-5 text-left">
                    <div class="flex justify-between items-center py-2.5 border-b border-gray-200 gap-2.5">
                        <span class="text-xs text-gray-500 whitespace-nowrap">店铺首页</span>
                        <span class="text-sm font-semibold text-right break-all"><a href="index.php" class="text-brand hover:underline"><i class="fa-solid fa-store"></i> <?= htmlspecialchars($siteUrl . '/index.php') ?></a></span>
                    </div>
                    <div class="flex justify-between items-center py-2.5 gap-2.5">
                        <span class="text-xs text-gray-500 whitespace-nowrap">后台管理</span>
                        <span class="text-sm font-semibold text-right break-all"><a href="admin.php" class="text-brand hover:underline"><i class="fa-solid fa-gear"></i> <?= htmlspecialchars($siteUrl . '/admin.php') ?></a></span>
                    </div>
                </div>

                <div class="space-y-2">
                    <a href="index.php" class="block w-full bg-brand hover:bg-brandHover text-white font-semibold px-8 py-3 rounded-lg transition text-center"><i class="fa-solid fa-store"></i> 进入店铺</a>
                    <a href="admin.php" class="block w-full border-2 border-brand text-brand hover:bg-brand/5 font-semibold px-8 py-3 rounded-lg transition text-center"><i class="fa-solid fa-gear"></i> 进入后台</a>
                </div>

                <div class="bg-amber-50 border border-amber-200 rounded-lg px-4 py-3 mt-5 text-left text-sm text-amber-700">
                    <i class="fa-solid fa-triangle-exclamation"></i> <strong>安全提示</strong>
                    <ul class="mt-2 mb-0 list-disc pl-5 space-y-1">
                        <li>建议删除 <code class="bg-amber-100 px-1 rounded">install.php</code> 和 <code class="bg-amber-100 px-1 rounded">core.zip</code> 文件，防止被他人利用</li>
                        <li>系统已自动创建 <code class="bg-amber-100 px-1 rounded">data/installed.lock</code> 锁定文件，阻止重复安装</li>
                        <li>如需重新安装，删除 <code class="bg-amber-100 px-1 rounded">data/installed.lock</code> 并重新上传 <code class="bg-amber-100 px-1 rounded">core.zip</code> 即可</li>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function startInstall() {
    const btn = document.getElementById('btnStartInstall');
    const progressArea = document.getElementById('progressArea');
    const progressBar = document.getElementById('progressBar');
    const progressPercent = document.getElementById('progressPercent');
    const extractLog = document.getElementById('extractLog');
    const installSection = document.getElementById('installSection');
    const completeSection = document.getElementById('completeSection');

    btn.disabled = true;
    btn.innerHTML = '<span class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-1 align-middle"></span> 准备中...';
    progressArea.style.display = 'block';

    let files = [];
    try {
        const resp = await fetch('install.php?action=get_files');
        const data = await resp.json();
        if (!data.success) {
            appendLog('error', '错误: ' + data.msg);
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-rocket"></i> 开始安装';
            return;
        }
        files = data.files;
    } catch (e) {
        appendLog('error', '错误: 无法获取文件列表');
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-rocket"></i> 开始安装';
        return;
    }

    if (files.length === 0) {
        appendLog('error', '错误: core.zip 中没有文件');
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-rocket"></i> 开始安装';
        return;
    }

    const totalSteps = files.length + 2;
    let currentStep = 0;

    function updateProgress(step) {
        const pct = Math.round((step / totalSteps) * 100);
        progressBar.style.width = pct + '%';
        progressPercent.textContent = pct + '%';
    }

    for (const file of files) {
        currentStep++;
        updateProgress(currentStep);
        appendLog('file', '提取：' + file);
        await sleep(30);
    }

    currentStep++;
    updateProgress(currentStep);
    appendLog('status', '> 正在安装，请稍候...');
    await sleep(500);

    progressBar.style.width = '95%';
    try {
        const resp = await fetch('install.php?action=extract', { method: 'POST' });
        const data = await resp.json();
        if (!data.success) {
            appendLog('error', '错误: ' + data.msg);
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-rocket"></i> 开始安装';
            return;
        }
    } catch (e) {
        appendLog('error', '错误: 安装请求失败');
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-rocket"></i> 开始安装';
        return;
    }

    progressBar.style.width = '100%';
    progressPercent.textContent = '100%';
    appendLog('success', '> 安装完成！');
    await sleep(500);

    installSection.style.display = 'none';
    completeSection.style.display = 'block';
}

function appendLog(type, text) {
    const log = document.getElementById('extractLog');
    const div = document.createElement('div');
    div.className = 'line';
    div.style.opacity = '1';
    if (type === 'file') {
        div.innerHTML = '  <span style="color:#0f0;">&#10003;</span> ' + escapeHtml(text);
    } else if (type === 'status') {
        div.innerHTML = '<span style="color:#ffd700;">' + escapeHtml(text) + '</span>';
    } else if (type === 'error') {
        div.innerHTML = '<span style="color:#f33;">' + escapeHtml(text) + '</span>';
    } else if (type === 'success') {
        div.innerHTML = '<span style="color:#0f0;font-weight:bold;">' + escapeHtml(text) + '</span>';
    }
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}
</script>
</body>
</html>